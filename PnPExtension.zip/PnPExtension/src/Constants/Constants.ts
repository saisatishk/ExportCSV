export class Constants {
    // Dev Flow Trigger URL
    //public flowTriggerURL = "https://383a68a90f7fe34c80bf315ec54741.0d.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/8d8c665a51c64855a87444da7628a75d/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=6mdOOSJiiJHYs9VLV17bvm_NKfT5JS15EDNjHOtBqCU";

    // QA Flow Trigger URL
    //public flowTriggerURL = "https://66cf57d44fd0e3e5bf9117e0315cee.0d.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/e0cc505151854b0e98d6978eb1afcf17/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=jcLDyRNpc3TgwQhjnZISQdXE1vVjjwraPNaD2brwmuM";

    // UAT Flow Trigger URL
    public flowTriggerURL = "https://e8a92863813be7e29bb3517d85e187.18.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/b3cee803a4ba492287e0497e1c57ac76/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=NqJKOHesYafU1QOrEge-7W7XCZNJuBI5vFO29EeKkz8";
}