import {
  BaseApplicationCustomizer
} from '@microsoft/sp-application-base';
import { Constants } from '../../Constants/Constants';
 
const LOG_SOURCE: string = 'PnPExtensionApplicationCustomizer';
let constantsObj = new Constants();
 
/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IPnPExtensionApplicationCustomizerProperties {
  // This is an example; replace with your own property
  testMessage: string;
}
 
/** A Custom Action which can be run during execution of a Client Side Application */
export default class PnPExtensionApplicationCustomizer
  extends BaseApplicationCustomizer<IPnPExtensionApplicationCustomizerProperties> {
  private _isExecuting: boolean = false;
 
  public onInit(): Promise<void> {
 
    /* ---------- Inject CSS (safe to run multiple times) ---------- */
    const existingStyle = document.getElementById("ipa-custom-style");
    if (!existingStyle) {
      const style = document.createElement("style");
      style.id = "ipa-custom-style";
      style.innerHTML = `
#fluent-default-layer-host .ms-Fabric .ms-ComboBox-optionsContainer {
  height: 90vh !important;
  overflow-y: auto !important;
  position: relative;
}
 
#fluent-default-layer-host .ms-Fabric .ms-ComboBox-optionsContainer > div[role="group"][aria-labelledby$="FILTER_MULTI"] {
  position: sticky !important;
  top: 0;
  z-index: 10 !important;
  background: #fff;
  padding-top: 2px;
}
 
#fluent-default-layer-host .ms-Fabric .ms-Callout-main {
  overflow-y: unset !important;
}
`;
      document.head.appendChild(style);
    }
 
    /* ---------- GLOBAL click handler guard ---------- */
    const w = window as any;
 
    if (!w.__ipaClickHandlerAttached__) {
      w.__ipaClickHandlerAttached__ = true;
 
      document.addEventListener("click", (event) => {
 
        const clickedElement = event.target as HTMLElement;
 
        const button =
          clickedElement.closest(".ipa-action-btn") as HTMLButtonElement | null;
 
        if (!button) {
          return;
        }
 
        /* CRITICAL: prevent summary + duplicate handlers */
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
 
        const documentId = button.getAttribute("data-documentid");
        const requestedBy = button.getAttribute("data-requestedby");
 
        if (!documentId || !requestedBy) {
          alert("Missing required data attributes");
          return;
        }
 
        const container = button.closest(".ipa-action-container");
        const toggle =
          container?.querySelector<HTMLInputElement>(".ipa-test-toggle");
 
        const isTestItem = toggle ? toggle.checked : false;
 
        this.executeFlow(documentId, requestedBy, isTestItem);
      });
 
      console.log("✅ IPA click handler registered ONCE");
    } else {
      console.log("⚠️ IPA click handler already exists — skipped");
    }
 
    return Promise.resolve();
  }
 
  private executeFlow(
    documentId: string,
    requestedBy: string,
    isTestItem: boolean
  ): void {
 
    if (this._isExecuting) {
      console.log("Blocked duplicate call");
      return;
    }
 
    this._isExecuting = true;
 
    const payload = {
      DocumentId: documentId,
      RequestedBy: requestedBy,
      IsTestItem: isTestItem
    };
 
    console.log("Execute flow");
 
    fetch(constantsObj.flowTriggerURL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    })
      .then(response => {
        if (!response.ok) {
          alert("❌ Failed to send document to IPA");
          throw new Error("Flow execution failed");
        }
        else if (response.ok) {
          alert("✅ Document sent to IPA successfully");
        }
        //this.showNotification("✅ Document sent to IPA successfully");
      })
      .catch(error => {
        console.error(error);
        alert("❌ Failed to send document to IPA");
      })
      .finally(() => {
        this._isExecuting = false;
      });
  }
 
}
