define([], function() {
  return {
    "Title": "PnPExtensionApplicationCustomizer"
  }
});