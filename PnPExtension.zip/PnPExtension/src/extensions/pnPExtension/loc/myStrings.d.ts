declare interface IPnPExtensionApplicationCustomizerStrings {
  Title: string;
}

declare module 'PnPExtensionApplicationCustomizerStrings' {
  const strings: IPnPExtensionApplicationCustomizerStrings;
  export = strings;
}
